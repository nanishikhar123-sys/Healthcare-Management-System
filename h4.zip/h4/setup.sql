-- Run this in MySQL to prepare the database
CREATE DATABASE IF NOT EXISTS hospital_management_system;
USE hospital_management_system;

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  role VARCHAR(30) NOT NULL
);

-- Default admin / doctor / receptionist (plain-text for demo)
INSERT INTO users (username, password, role) VALUES
  ('admin', 'admin', 'ADMIN')
ON DUPLICATE KEY UPDATE password = VALUES(password), role = VALUES(role);

INSERT INTO users (username, password, role) VALUES
  ('doctor1', 'doctor1', 'DOCTOR'),
  ('reception', 'reception', 'RECEPTIONIST')
ON DUPLICATE KEY UPDATE password = VALUES(password), role = VALUES(role);

CREATE TABLE IF NOT EXISTS patients (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200),
  age INT,
  gender VARCHAR(10),
  disease VARCHAR(255),
  room VARCHAR(50),
  deposit DOUBLE,
  admit_date DATE,
  release_date DATE
);

CREATE TABLE IF NOT EXISTS doctors (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  specialization VARCHAR(200),
  phone VARCHAR(20),
  email VARCHAR(200)
);

CREATE TABLE IF NOT EXISTS appointments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  appointment_date DATETIME NOT NULL,
  status VARCHAR(50) DEFAULT 'Scheduled',
  notes VARCHAR(500),
  CONSTRAINT fk_app_patient FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  CONSTRAINT fk_app_doctor FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS bills (
  id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  amount DOUBLE NOT NULL,
  description VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_bill_patient FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);
