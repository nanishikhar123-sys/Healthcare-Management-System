# Hospital Management System (HMS)

This is a simple **Java JSP/Servlet + MySQL** Hospital Management System with a
**Material Design-style UI (using Materialize CSS)**.

## Features

- Login & role-based access (demo users)
  - `admin / admin` → ADMIN
  - `doctor1 / doctor1` → DOCTOR
  - `reception / reception` → RECEPTIONIST
- Dashboard with counters:
  - Total Patients
  - Total Doctors
  - Total Appointments
  - Total Bills
- Patients module (CRUD)
- Doctors module (CRUD)
- Appointments module (patient–doctor bookings)
- Billing module (generate bills for patients)
- MySQL database with DAO layer (JDBC)

> **Note:** Passwords are stored in plain text for educational/demo purposes.
> For production, always hash passwords.

## Tech Stack

- Java 17
- JSP / Servlets (Jakarta)
- Materialize CSS (for Material Design look)
- MySQL
- Maven (WAR project)
- Runs on Tomcat 10+ (or any Jakarta EE 10 compatible server)

## Setup

1. Create the database and tables:

   - Open MySQL client and run:

   ```sql
   SOURCE setup.sql;
   ```

2. Update DB credentials in:

   - `src/main/java/com/hospital/util/DBUtil.java`

3. Build the project:

   ```bash
   mvn clean package
   ```

4. Deploy the generated `hospital-management-system.war` to Tomcat.

5. Open in browser:

   - `http://localhost:8080/hospital-management-system/login.jsp`

## Default Users

- Admin: `admin / admin`
- Doctor: `doctor1 / doctor1`
- Receptionist: `reception / reception`

You can change or add more users in the `users` table.
