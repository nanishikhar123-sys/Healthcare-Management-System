package com.hospital.dao;

import com.hospital.model.Bill;
import com.hospital.util.DBUtil;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class BillDAO {

    public List<Bill> findAll() throws SQLException {
        List<Bill> list = new ArrayList<>();
        String sql = "SELECT id, patient_id, amount, description, created_at FROM bills ORDER BY created_at DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Bill b = new Bill();
                b.setId(rs.getInt("id"));
                b.setPatientId(rs.getInt("patient_id"));
                b.setAmount(rs.getDouble("amount"));
                b.setDescription(rs.getString("description"));
                Timestamp ts = rs.getTimestamp("created_at");
                b.setCreatedAt(ts != null ? ts.toLocalDateTime() : null);
                list.add(b);
            }
        }
        return list;
    }

    public Bill findById(int id) throws SQLException {
        String sql = "SELECT id, patient_id, amount, description, created_at FROM bills WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Bill b = new Bill();
                    b.setId(rs.getInt("id"));
                    b.setPatientId(rs.getInt("patient_id"));
                    b.setAmount(rs.getDouble("amount"));
                    b.setDescription(rs.getString("description"));
                    Timestamp ts = rs.getTimestamp("created_at");
                    b.setCreatedAt(ts != null ? ts.toLocalDateTime() : null);
                    return b;
                }
            }
        }
        return null;
    }

    public void add(Bill b) throws SQLException {
        String sql = "INSERT INTO bills(patient_id, amount, description) VALUES(?,?,?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, b.getPatientId());
            ps.setDouble(2, b.getAmount());
            ps.setString(3, b.getDescription());
            ps.executeUpdate();
        }
    }

    public void update(Bill b) throws SQLException {
        String sql = "UPDATE bills SET patient_id=?, amount=?, description=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, b.getPatientId());
            ps.setDouble(2, b.getAmount());
            ps.setString(3, b.getDescription());
            ps.setInt(4, b.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM bills WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public int count() throws SQLException {
        String sql = "SELECT COUNT(*) FROM bills";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
}
