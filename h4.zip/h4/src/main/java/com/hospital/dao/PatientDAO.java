package com.hospital.dao;

import com.hospital.model.Patient;
import com.hospital.util.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO {

    public List<Patient> findAll() throws SQLException {
        List<Patient> list = new ArrayList<>();
        String sql = "SELECT id, name, age, gender, disease, room, deposit FROM patients ORDER BY id DESC";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Patient p = new Patient();
                p.setId(rs.getInt("id"));
                p.setName(rs.getString("name"));
                p.setAge(rs.getInt("age"));
                p.setGender(rs.getString("gender"));
                p.setDisease(rs.getString("disease"));
                p.setRoom(rs.getString("room"));
                p.setDeposit(rs.getDouble("deposit"));
                list.add(p);
            }
        }
        return list;
    }

    public Patient findById(int id) throws SQLException {
        String sql = "SELECT id, name, age, gender, disease, room, deposit FROM patients WHERE id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Patient p = new Patient();
                    p.setId(rs.getInt("id"));
                    p.setName(rs.getString("name"));
                    p.setAge(rs.getInt("age"));
                    p.setGender(rs.getString("gender"));
                    p.setDisease(rs.getString("disease"));
                    p.setRoom(rs.getString("room"));
                    p.setDeposit(rs.getDouble("deposit"));
                    return p;
                }
            }
        }
        return null;
    }

    public void add(Patient p) throws SQLException {
        String sql = "INSERT INTO patients(name, age, gender, disease, room, deposit, admit_date) VALUES(?,?,?,?,?,?,CURRENT_DATE())";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getName());
            ps.setInt(2, p.getAge());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getDisease());
            ps.setString(5, p.getRoom());
            ps.setDouble(6, p.getDeposit());
            ps.executeUpdate();
        }
    }

    public void update(Patient p) throws SQLException {
        String sql = "UPDATE patients SET name=?, age=?, gender=?, disease=?, room=?, deposit=? WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, p.getName());
            ps.setInt(2, p.getAge());
            ps.setString(3, p.getGender());
            ps.setString(4, p.getDisease());
            ps.setString(5, p.getRoom());
            ps.setDouble(6, p.getDeposit());
            ps.setInt(7, p.getId());
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM patients WHERE id=?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public int count() throws SQLException {
        String sql = "SELECT COUNT(*) FROM patients";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }
}
