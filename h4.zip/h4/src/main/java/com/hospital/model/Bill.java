package com.hospital.model;

import java.time.LocalDateTime;

public class Bill {
    private int id;
    private int patientId;
    private double amount;
    private String description;
    private LocalDateTime createdAt;

    public Bill() {}

    public Bill(int id, int patientId, double amount, String description, LocalDateTime createdAt) {
        this.id = id;
        this.patientId = patientId;
        this.amount = amount;
        this.description = description;
        this.createdAt = createdAt;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
