package com.hospital.servlet;

import com.hospital.dao.PatientDAO;
import com.hospital.model.Patient;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/patients")
public class PatientServlet extends HttpServlet {

    private final PatientDAO dao = new PatientDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!isLoggedIn(req)) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        try {
            List<Patient> patients = dao.findAll();
            req.setAttribute("patients", patients);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
        req.getRequestDispatcher("/patients.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!isLoggedIn(req)) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        String action = req.getParameter("action");
        try {
            if ("add".equals(action)) {
                Patient p = buildPatientFromRequest(req);
                dao.add(p);
            } else if ("update".equals(action)) {
                Patient p = buildPatientFromRequest(req);
                p.setId(Integer.parseInt(req.getParameter("id")));
                dao.update(p);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                dao.delete(id);
            }
            resp.sendRedirect(req.getContextPath() + "/patients");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private Patient buildPatientFromRequest(HttpServletRequest req) {
        Patient p = new Patient();
        p.setName(req.getParameter("name"));
        p.setAge(Integer.parseInt(req.getParameter("age")));
        p.setGender(req.getParameter("gender"));
        p.setDisease(req.getParameter("disease"));
        p.setRoom(req.getParameter("room"));
        p.setDeposit(Double.parseDouble(req.getParameter("deposit")));
        return p;
    }

    private boolean isLoggedIn(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        return session != null && session.getAttribute("user") != null;
    }
}
