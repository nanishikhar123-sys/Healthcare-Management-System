package com.hospital.servlet;

import com.hospital.dao.BillDAO;
import com.hospital.dao.PatientDAO;
import com.hospital.model.Bill;
import com.hospital.model.Patient;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

@WebServlet("/bills")
public class BillServlet extends HttpServlet {

    private final BillDAO dao = new BillDAO();
    private final PatientDAO patientDAO = new PatientDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!isLoggedIn(req)) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        try {
            List<Bill> bills = dao.findAll();
            List<Patient> patients = patientDAO.findAll();
            req.setAttribute("bills", bills);
            req.setAttribute("patients", patients);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
        req.getRequestDispatcher("/bills.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!isLoggedIn(req)) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        String action = req.getParameter("action");
        try {
            if ("add".equals(action)) {
                Bill b = buildBill(req);
                dao.add(b);
            } else if ("update".equals(action)) {
                Bill b = buildBill(req);
                b.setId(Integer.parseInt(req.getParameter("id")));
                dao.update(b);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                dao.delete(id);
            }
            resp.sendRedirect(req.getContextPath() + "/bills");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private Bill buildBill(HttpServletRequest req) {
        Bill b = new Bill();
        b.setPatientId(Integer.parseInt(req.getParameter("patientId")));
        b.setAmount(Double.parseDouble(req.getParameter("amount")));
        b.setDescription(req.getParameter("description"));
        b.setCreatedAt(LocalDateTime.now());
        return b;
    }

    private boolean isLoggedIn(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        return session != null && session.getAttribute("user") != null;
    }
}
