package com.hospital.servlet;

import com.hospital.dao.DoctorDAO;
import com.hospital.model.Doctor;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/doctors")
public class DoctorServlet extends HttpServlet {

    private final DoctorDAO dao = new DoctorDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!isLoggedIn(req)) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        try {
            List<Doctor> doctors = dao.findAll();
            req.setAttribute("doctors", doctors);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
        req.getRequestDispatcher("/doctors.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!isLoggedIn(req)) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        String action = req.getParameter("action");
        try {
            if ("add".equals(action)) {
                Doctor d = buildDoctor(req);
                dao.add(d);
            } else if ("update".equals(action)) {
                Doctor d = buildDoctor(req);
                d.setId(Integer.parseInt(req.getParameter("id")));
                dao.update(d);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                dao.delete(id);
            }
            resp.sendRedirect(req.getContextPath() + "/doctors");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private Doctor buildDoctor(HttpServletRequest req) {
        Doctor d = new Doctor();
        d.setName(req.getParameter("name"));
        d.setSpecialization(req.getParameter("specialization"));
        d.setPhone(req.getParameter("phone"));
        d.setEmail(req.getParameter("email"));
        return d;
    }

    private boolean isLoggedIn(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        return session != null && session.getAttribute("user") != null;
    }
}
