package com.hospital.servlet;

import com.hospital.dao.AppointmentDAO;
import com.hospital.dao.DoctorDAO;
import com.hospital.dao.PatientDAO;
import com.hospital.model.Appointment;
import com.hospital.model.Doctor;
import com.hospital.model.Patient;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@WebServlet("/appointments")
public class AppointmentServlet extends HttpServlet {

    private final AppointmentDAO dao = new AppointmentDAO();
    private final PatientDAO patientDAO = new PatientDAO();
    private final DoctorDAO doctorDAO = new DoctorDAO();
    private final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!isLoggedIn(req)) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        try {
            List<Appointment> appointments = dao.findAll();
            List<Patient> patients = patientDAO.findAll();
            List<Doctor> doctors = doctorDAO.findAll();
            req.setAttribute("appointments", appointments);
            req.setAttribute("patients", patients);
            req.setAttribute("doctors", doctors);
        } catch (SQLException e) {
            throw new ServletException(e);
        }
        req.getRequestDispatcher("/appointments.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        if (!isLoggedIn(req)) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        String action = req.getParameter("action");
        try {
            if ("add".equals(action)) {
                Appointment a = buildAppointment(req);
                dao.add(a);
            } else if ("update".equals(action)) {
                Appointment a = buildAppointment(req);
                a.setId(Integer.parseInt(req.getParameter("id")));
                dao.update(a);
            } else if ("delete".equals(action)) {
                int id = Integer.parseInt(req.getParameter("id"));
                dao.delete(id);
            }
            resp.sendRedirect(req.getContextPath() + "/appointments");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private Appointment buildAppointment(HttpServletRequest req) {
        Appointment a = new Appointment();
        a.setPatientId(Integer.parseInt(req.getParameter("patientId")));
        a.setDoctorId(Integer.parseInt(req.getParameter("doctorId")));
        String dateTime = req.getParameter("appointmentDate");
        LocalDateTime ldt = LocalDateTime.parse(dateTime, formatter);
        a.setAppointmentDate(ldt);
        a.setStatus(req.getParameter("status"));
        a.setNotes(req.getParameter("notes"));
        return a;
    }

    private boolean isLoggedIn(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        return session != null && session.getAttribute("user") != null;
    }
}
